package com.aip.mode.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.aip.model.entity.ConnectionFactory;
import com.aip.model.entity.Defaulter;
import com.aip.model.entity.User;
import com.aip.model.inter.DefaulterDAO;


public class DefaultDAOImpl implements DefaulterDAO {
	Connection con=null;
	public DefaultDAOImpl() {
		con=ConnectionFactory.openConn();
	}
	
	@Override
	public int saveDefaulter(Defaulter abc) {
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("insert into default_status values(?,?,?,?,?,?,?,?)");
            ps.setString(1,abc.getDefault_status());
            ps.setString(2,abc.getBorrower_name());
            ps.setString(3,abc.getBorrower_rating());
            ps.setString(4,abc.getAccural_status());
            ps.setString(5,abc .getAccount_number());
            ps.setString(6,abc.getDays_past_due());
            ps.setString(7,abc.getComments()); 
            ps.setString(8, abc.getUser_id());
            status=ps.executeUpdate();

		}catch (Exception e) {
			System.out.println("Error in Insert Defaulter "+e);
		}
		return status;
	}

	@Override
	public int updateDefaulter(Defaulter def) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteDefaulter(int userid) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Defaulter getDefaulterById(String userid) {
		Defaulter defaulter=null;
		try {
			PreparedStatement ps=con.prepareStatement("select * from default_status where User_id=?");
            ps.setString(1,userid);            
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {          
            	defaulter=new Defaulter();
            	defaulter.setDefault_status(rs.getString(1));
            	defaulter.setBorrower_name(rs.getString(2));
            	defaulter.setBorrower_rating(rs.getString(3));
            	defaulter.setAccural_status(rs.getString(4));
            	defaulter.setAccount_number(rs.getString(5));
            	defaulter.setDays_past_due(rs.getString(6));
            	defaulter.setComments(rs.getString(7));
            }
            
		}catch (Exception e) {
			System.out.println("Error in Get All User "+e);
		}
		return defaulter;
	}

	public List<Defaulter> getDefaulterByStatus(String status) {
		List<Defaulter> deflist=new ArrayList<Defaulter>();
		try {
			int i=0;
			PreparedStatement ps=con.prepareStatement("select * from default_status where Default_status=?");
            ps.setString(1,status);            
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {          
            	i++;
            	Defaulter defaulter=new Defaulter();
            	defaulter=new Defaulter();
            	defaulter.setDefault_status(rs.getString(1));
            	defaulter.setBorrower_name(rs.getString(2));
            	defaulter.setBorrower_rating(rs.getString(3));
            	defaulter.setAccural_status(rs.getString(4));
            	defaulter.setAccount_number(rs.getString(5));
            	defaulter.setDays_past_due(rs.getString(6));
            	defaulter.setComments(rs.getString(7));
            	defaulter.setUser_id(rs.getString(8));
            	deflist.add(defaulter);
            }
            System.out.println("Count :"+i);
		}catch (Exception e) {
			System.out.println("Error in Get by Status  "+e);
		}
		return deflist;
	}

	
	@Override
	public List<Defaulter> getAllDefaulter() {
		// TODO Auto-generated method stub
		return null;
	}


}
