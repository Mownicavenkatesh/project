package com.aip.controller.user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aip.model.entity.User;
import com.aip.model.inter.UserDAO;
import com.aip.mode.impl.UserDAOImpl;


/**
 * Servlet implementation class AddUser
 */
@WebServlet("/DeleteUser.do")
public class DeleteUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		
		String User_id=request.getParameter("User_id");
		
		
		UserDAO abcdao=new UserDAOImpl();
		int status=abcdao.deleteUser(User_id);
		if(status==1)
		{
			System.out.println("Pass");
			request.setAttribute("msg", "User deleted Successfully");	
			RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
			//pw.println("<span style=color:green;size:20px; >User Updated Successfully</span>");
			
			rd.forward(request, response);
		}
		else
		{
			System.out.println("Fail");
			RequestDispatcher rd=request.getRequestDispatcher("registration_form.jsp");
			request.setAttribute("msg", "User delete Failed");			
			//pw.println("<center><span style=color:red;size:20px>Password or User_id is incorrect </span></center>");
			rd.forward(request, response);
		}
	}
}
