package com.aip.controller.user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aip.model.entity.Defaulter;
import com.aip.model.entity.User;
import com.aip.model.inter.DefaulterDAO;
import com.aip.model.inter.UserDAO;
import com.aip.mode.impl.DefaultDAOImpl;
import com.aip.mode.impl.UserDAOImpl;


/**
 * Servlet implementation class AddUser
 */
@WebServlet("/DefaultStatus.do")
public class DefaultStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DefaultStatus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String Default_status=request.getParameter("defaultstatus");
		String Borrower_name=request.getParameter("brname");
		String Borrower_rating=request.getParameter("brrating");
		String Accural_status=request.getParameter("accstatus");
		String Account_number=request.getParameter("accno");
		String Days_past_due=request.getParameter("dpd");
		String Comments=request.getParameter("comments");
		String User_id=request.getParameter("User_id");
		
		Defaulter abc=new Defaulter(User_id, Default_status, Borrower_name, Borrower_rating, Accural_status, Account_number, Days_past_due, Comments);
		DefaulterDAO abcdao=new DefaultDAOImpl();
		int status=abcdao.saveDefaulter(abc);
		
		if(status==1)
		{
			//RequestDispatcher rd=request.getRequestDispatcher("default_status.jsp");
			RequestDispatcher rd=request.getRequestDispatcher("GetAllUser.jsp");
			//pw.println("<span style=color:green;size:20px;>Default Added Successfully</span>");
			//request.setAttribute("msg", "Default Status Added Successfully");
			request.setAttribute("msg", "Default Status added successfully");
			rd.include(request, response);
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("default_status.jsp");
			pw.println("<span style=color:red;size:20px>Failed User Adding </span>");
			rd.include(request, response);
		}
	}
}


