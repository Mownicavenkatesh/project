package com.aip.model.entity;

import java.io.Serializable;

public class Defaulter implements Serializable {
	private String User_id;
	private String Default_status;
	private String Borrower_name;
	private String Borrower_rating;
	private String Accural_status;
	private String Account_number;
	private String Days_past_due;
	private String Comments;
	public String getDefault_status() {
		return Default_status;
	}
	public void setDefault_status(String default_status) {
		Default_status = default_status;
	}
	public String getBorrower_name() {
		return Borrower_name;
	}
	public void setBorrower_name(String borrower_name) {
		Borrower_name = borrower_name;
	}
	public String getBorrower_rating() {
		return Borrower_rating;
	}
	public void setBorrower_rating(String borrower_rating) {
		Borrower_rating = borrower_rating;
	}
	public String getAccural_status() {
		return Accural_status;
	}
	public void setAccural_status(String accural_status) {
		Accural_status = accural_status;
	}
	public String getAccount_number() {
		return Account_number;
	}
	public void setAccount_number(String account_number) {
		Account_number = account_number;
	}
	public String getDays_past_due() {
		return Days_past_due;
	}
	public void setDays_past_due(String days_past_due) {
		Days_past_due = days_past_due;
	}
	public String getComments() {
		return Comments;
	}
	public void setComments(String comments) {
		Comments = comments;
	}
	public Defaulter(String default_status, String borrower_name, String borrower_rating, String accural_status,
			String account_number, String days_past_due, String comments) {
		super();
		Default_status = default_status;
		Borrower_name = borrower_name;
		Borrower_rating = borrower_rating;
		Accural_status = accural_status;
		Account_number = account_number;
		Days_past_due = days_past_due;
		Comments = comments;
	}
	public String getUser_id() {
		return User_id;
	}
	public void setUser_id(String user_id) {
		User_id = user_id;
	}
	public Defaulter(String user_id, String default_status, String borrower_name, String borrower_rating,
			String accural_status, String account_number, String days_past_due, String comments) {
		super();
		User_id = user_id;
		Default_status = default_status;
		Borrower_name = borrower_name;
		Borrower_rating = borrower_rating;
		Accural_status = accural_status;
		Account_number = account_number;
		Days_past_due = days_past_due;
		Comments = comments;
	}
	public Defaulter() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
