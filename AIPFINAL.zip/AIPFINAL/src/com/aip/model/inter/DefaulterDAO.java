package com.aip.model.inter;

import java.util.List;

import com.aip.model.entity.Defaulter;

public interface DefaulterDAO {
	public int saveDefaulter(Defaulter def);
	public int updateDefaulter(Defaulter def);
	public int deleteDefaulter(int userid);
	public Defaulter getDefaulterById(String userid);
	public List<Defaulter> getAllDefaulter();
	public List<Defaulter> getDefaulterByStatus(String status);
}
